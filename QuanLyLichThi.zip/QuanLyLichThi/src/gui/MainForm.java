
package gui;

public class MainForm extends javax.swing.JFrame {
    public MainForm() {
        initComponents();
        loadData(); // Đã thêm lệnh gọi hàm ở đây để bảng hiện dữ liệu
    }
public void loadData() {
    try {
        // Kết nối đến database
        helpers.DBConText db = new helpers.DBConText(); 
        java.sql.Connection conn = db.getConnection();

        // SQL lấy thông tin User (2 cột đầu) và Lịch thi (6 cột sau)
        String sql = "SELECT u.Username, u.FullName, lt.MaLichThi, mh.TenMon, "
                   + "pt.TenPhong, lt.NgayThi, lt.CaThi, lt.HinhThucThi "
                   + "FROM Users u, LichThi lt "
                   + "JOIN MonHoc mh ON lt.MaMon = mh.MaMon "
                   + "JOIN PhongThi pt ON lt.MaPhong = pt.MaPhong "
                   + "WHERE u.Username = 'Admin@gmail.com'"; 

        java.sql.PreparedStatement st = conn.prepareStatement(sql);
        java.sql.ResultSet rs = st.executeQuery();

        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tblData.getModel();
        model.setRowCount(0); 

        while (rs.next()) {
            Object[] row = {
                rs.getString("Username"),    // Cột 1: Email
                rs.getString("FullName"),    // Cột 2: Họ tên
                rs.getInt("MaLichThi"),      // Cột 3: Mã lịch
                rs.getString("TenMon"),       // Cột 4: Tên môn
                rs.getString("TenPhong"),     // Cột 5: Phòng
                rs.getDate("NgayThi"),       // Cột 6: Ngày
                "Ca " + rs.getInt("CaThi"),  // Cột 7: Ca
                rs.getString("HinhThucThi")  // Cột 8: Hình thức
            };
            model.addRow(row);
        }
        conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblData = new javax.swing.JTable();
        btnLogout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("HỆ THỐNG QUẢN LÝ LỊCH THI - SINH VIÊN: PHƯƠNG LINH");

        tblData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Email/Username", "Họ và tên", "Mã lịch", "Tên môn học", "Phòng thi", "Ngày thi", "Ca thi", "Hình thức thi"
            }
        ));
        tblData.setRowHeight(30);
        jScrollPane1.setViewportView(tblData);

        btnLogout.setText("Đăng xuất");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(315, 315, 315))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1231, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnLogout)
                        .addGap(165, 165, 165))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addComponent(jLabel1)
                .addGap(80, 80, 80)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 476, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(btnLogout)
                .addGap(74, 74, 74))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
// 1. Hiện thông báo xác nhận cho chắc chắn
    int choice = javax.swing.JOptionPane.showConfirmDialog(this, "Linh có chắc muốn đăng xuất không?", "Xác nhận", javax.swing.JOptionPane.YES_NO_OPTION);
    
    if (choice == javax.swing.JOptionPane.YES_OPTION) {
        // 2. Mở lại trang Login
        new LoginForm().setVisible(true);
        // 3. Đóng trang chủ hiện tại
        this.dispose();
    }        // TODO add your handling code here:
    }//GEN-LAST:event_btnLogoutActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogout;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblData;
    // End of variables declaration//GEN-END:variables


}
