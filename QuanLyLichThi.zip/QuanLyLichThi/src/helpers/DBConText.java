package helpers;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConText {
    
    /* Cấu hình kết nối */
    private final String serverName = "localhost";
    private final String dbName = "QuanLyLichThi"; // Linh nhớ kiểm tra đúng tên Database trong SQL của mình nhé
    private final String portNumber = "1433";
    private final String instance = "SQLEXPRESS"; // Dành riêng cho bản Express của Linh
    private final String userID = "sa";
    private final String password = "123"; // Mật khẩu SQL của Linh

    public Connection getConnection() throws Exception {
        // Địa chỉ kết nối đã được sửa cho bản SQLEXPRESS
        String url = "jdbc:sqlserver://" + serverName + "\\" + instance + ":" + portNumber 
                    + ";databaseName=" + dbName 
                    + ";encrypt=true;trustServerCertificate=true";
        
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        return DriverManager.getConnection(url, userID, password);
    }

    public static void main(String[] args) {
        try {
            System.out.println(new DBConText().getConnection());
            System.out.println("Kết nối thành công rồi nè Linh ơi!");
        } catch (Exception e) {
            System.out.println("Vẫn lỗi nè: " + e.getMessage());
        }
    }
}